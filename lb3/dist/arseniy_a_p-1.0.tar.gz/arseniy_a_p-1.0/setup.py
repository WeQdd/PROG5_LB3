from setuptools import setup

setup(
    name='arseniy-a-p',
    version='1.0',
    packages=['arseniy-a-p'],
    install_requires=[]
)